# 🌌 3D Solar System Simulation (Three.js + VR)

This project is a 3D simulation of the solar system built using [Three.js](https://threejs.org/), complete with:

- 🪐 Realistic planet orbits around the sun
- 🔁 Adjustable orbital speeds for each planet
- 🔄 Pause/Resume animation button
- 🌗 Dark/Light theme toggle
- 🛰 Tooltips on hover
- 🔭 Click to zoom/focus on a planet
- 🧑‍🚀 Mobile VR support (via WebXR)
- 💍 Saturn's rings included!

## 🚀 How to Run

1. **Download or Clone this Repository**
2. Open `index.html` in any modern browser (Chrome/Firefox with WebXR support)
3. Use the control panel to interact with the simulation

## 📦 Tech Stack

- [Three.js](https://threejs.org/)
- WebXR API
- Plain HTML/CSS/JavaScript

## 🕶 VR Usage

If your device supports WebXR:
- Click the **Enter VR** button
- Insert into a compatible headset (e.g., Google Cardboard or Meta Quest browser)

## 📁 Project Structure

```
solar-system-vr/
├── index.html       # Main simulation file
├── README.md        # Project description and instructions
```

## 📸 Preview

![Solar System Screenshot](screenshot.png) *(Add your screenshot here)*

---

Feel free to fork or enhance the project. Contributions welcome!
